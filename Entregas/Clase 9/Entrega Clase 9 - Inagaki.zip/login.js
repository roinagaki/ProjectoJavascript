(function(){
    $(document).ready(function(){
        $('.alt-form').click(function(){
            $('.form-contenido').animate({
                height: "toggle",
                opacity: 'toggle'
            }, 600); 

        });
    })
}())

