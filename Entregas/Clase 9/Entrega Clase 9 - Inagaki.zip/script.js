let nombreIngresado = prompt("Nombre Completo");
let mensaje_a_mostrar = "!Bienvenido " + nombreIngresado + "!";
console.log(mensaje_a_mostrar);

if (confirm("Ingrese Contraseña")){
    let contraseñaOk = false;
    for (let i = 1; i <= 3; i++){
        let usuario = prompt ("Ingrese -" + i + " vez");

        if (usuario === "555"){
            contraseñaOk = true;
            break;
        }
    }

    if (contraseñaOk){
    alert("Contraseña Exitosa");
    } else {
    alert("Contrseña Incorreta")
    }

}


let nombre = localStorage.getItem("nombre")
if (nombre == null) {
    nombre = prompt("Ingrese usuario")
}

let campoSaludo = document.getElementById("LogIn")
campoSaludo.innerHTML = `Bienvenido ${nombre}` ;


const carrito = []

let btn1 = document.getElementById("product1");
btn1.addEventListener("click", () => {
    producto = "Pantalón Bebé"
    agregarElemento(producto)

})

let btn2 = document.getElementById("product2");
btn2.addEventListener("click", () => {
    producto = "Chaleco Bebé"
    agregarElemento(producto)

})

let btn3 = document.getElementById("product3");
btn3.addEventListener("click", () => {
    producto = "Vestido"
    agregarElemento(producto)

})

let btn4 = document.getElementById("product4");
btn4.addEventListener("click", () => {
    producto = "Body Bebé"
    agregarElemento(producto)
    

})

function agregarElemento(producto) {
    carrito.push(producto)

    alert ("Agregaste  " + producto)
}


/*class Producto {
    constructor (dato){
        this.tipo = dato.tipo;
        this.talle = dato.talle;
        this.color = dato.color;
        this. precio = dato.precio;
        this.stock = 10;
        this.vendido = false;


    }

    sumarIva () {
        this.precio = this.precio * 1.21;

    }

    vender() {
        if (this.stock == 0){
            console.log( "Perdón, no hay stock disponible")
        } else {
            console.lof (" Disponible, Vendido")

        }
        this.stock--;

    }

    refill() {
        this.stock += 10;

    }
}

let Tienda = [
    new Producto ( {tipo: "Pantalón", talle: "XL", color: "Negro", precio:  3200}),
    new Producto ( {tipo: "Remera", talle: "L", color: "Azul", precio:  1100}),
    new Producto ( {tipo: "Bermuda", talle: "L", color: "Camel", precio:  2200}),
    new Producto ( {tipo: "Camisa", talle: "XL", color: "Negro", precio:  2700}),
    new Producto ( {tipo: "Vestido", talle: "M", color: "Gris", precio:  3100}),
    new Producto ( {tipo: "Sweater", talle: "XS", color: "Blanco", precio:  2550}),
    new Producto ( {tipo: "Buzo", talle: "S", color: "Negro", precio:  2780}),
]

carrito = [] */

