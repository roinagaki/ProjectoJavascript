let nombreIngresado = prompt("Nombre Completo");
let mensaje_a_mostrar = "!Bienvenido " + nombreIngresado + "!";
console.log(mensaje_a_mostrar);
