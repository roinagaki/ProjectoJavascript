class Producto {
    constructor(tipo, talle, color, precio){ 
        this.tipo = tipo;
        this.talle = talle;
        this.color = color;
        this.precio = parseFloat(precio);
        this.stock = 100;
        this.vendido = false;
}

    vender() {
        this.stock = this.stock -1;
        this.vendido = true;
    }

    sumarIva (){
        this.precio = this.precio * 1.21;
    }
}

    
const Producto1 = new Producto ("Pantalon", "XL", "Negro", 3200);
const Producto2 = new Producto ("Remera", "L", "Azul", 1100);
const Producto3 = new Producto ("Bermuda", "L", "Camel", 2200);
const Producto4 = new Producto ("Camisa", "XL", "Negro", 2700);
const Producto5 = new Producto ("Vestido", "M", "Gris", 3100);
const Producto6 = new Producto ("Sweater", "XS", "Negro", 2550);
const Producto7 = new Producto ("Buzo", "S", "Blanco", 2780);
Producto1.sumarIva();
Producto2.sumarIva();
Producto1.vender();

