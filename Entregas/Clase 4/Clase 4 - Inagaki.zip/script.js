
/**let preciosiniva = parseInt(prompt("Ingrese el precio"));
let iva = 1.21;

function calculariva(precio, iva){
    let resultado = precio * iva;
    return resultado;
}

function preciofinal (final) {
    alert("El precio final es: $" + final);

}

preciofinal(calculariva(preciosiniva + iva));


**/

let entrada = parseInt(prompt("Bievenido, ingrese el numero solicitado segun la operacion que desera realizar: \n 1)realizar una factura \n 2)calcular retencion de ganancias en un pagos \n 3)salir"));

let precioIva = 0; 
let precioSinIva = 0;

function iva() {
    precioIva = facturacion * 0.21;
    precioSinIva = facturacion / 1.21;
    precioIva = precioIva.toFixed(2);
    precioSinIva = precioSinIva.toFixed(2);
    alert("usted debe facturar $" + precioSinIva + " de los cuales $" + precioIva + " son correspondientes a IVA");
    return false;
}

function ganancias() {
    let pagar = parseInt(prompt("ingrese el valor dle pago que desea realizar"));
    let precioGan = pagar * 0.02;
    let precioSinGan = pagar / 1;
    precioGan = precioGan.toFixed(2);
    precioSinGan = precioSinGan.toFixed(2);
    alert("usted debe pagar $" + precioSinGan + " ya que $" + precioGan + " pertence a retenciones de ganancias");
    return false;
}

while(entrada === 1 || entrada === 2) {

    switch (entrada){
        case 1:
            facturacion = parseInt(prompt("ingrese el valor que desea facturar"));
            iva(facturacion);
            break;
        case 2:
            ganancias();
            break;
    }
    
    entrada = parseInt(prompt("Bievenido, ingrese el numero solicitado segun la operacion que desera realizar: \n 1)facturas \n 2)pagos \n 3)salir"));
}
    

