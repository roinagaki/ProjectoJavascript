let nombreIngresado = prompt("Nombre Completo");
let mensaje_a_mostrar = "!Bienvenido " + nombreIngresado + "!";
console.log(mensaje_a_mostrar);

if (confirm("Ingrese Contraseña")){
    let contraseñaOk = false;
    for (let i = 1; i <= 3; i++){
        let usuario = prompt ("Ingrese -" + i + " vez");

        if (usuario === "555"){
            contraseñaOk = true;
            break;
        }
    }

    if (contraseñaOk){
    alert("Contraseña Exitosa");
    } else {
    alert("Contrseña Incorreta")
    }

}


class Producto {
    constructor (dato){
        this.tipo = dato.tipo;
        this.talle = dato.talle;
        this.color = dato.color;
        this. precio = dato.precio;
        this.stock = 100;
        this.vendido = false;


    }

    sumarIva () {
        this.precio = this.precio * 1.21;

    }

    vender() {
        if (this.stock == 0){
            console.log( "Perdón, no hay stock disponible")
        } else {
            console.lof (" Disponible, Vendido")

        }
        this.stock--;

    }

    refill() {
        this.stock += 10;

    }
}

let Tienda = [
    new Producto ( {tipo: "Pantalón", talle: "XL", color: "Negro", precio:  3200}),
    new Producto ( {tipo: "Remera", talle: "L", color: "Azul", precio:  1100}),
    new Producto ( {tipo: "Bermuda", talle: "L", color: "Camel", precio:  2200}),
    new Producto ( {tipo: "Camisa", talle: "XL", color: "Negro", precio:  2700}),
    new Producto ( {tipo: "Vestido", talle: "M", color: "Gris", precio:  3100}),
    new Producto ( {tipo: "Sweater", talle: "XS", color: "Blanco", precio:  2550}),
    new Producto ( {tipo: "Buzo", talle: "S", color: "Negro", precio:  2780}),
]

carrito = []
