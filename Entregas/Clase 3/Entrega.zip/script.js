if (confirm("Ingrese Contraseña")){
    let contraseñaOk = false;
    for (let i = 1; i <= 3; i++){
        let usuario = prompt ("Ingrese -" + i + " vez");

        if (usuario === "555"){
            contraseñaOk = true;
            break;
        }
    }




    if (contraseñaOk){
    alert("Contraseña Exitosa");
    } else {
    alert("Contrseña Incorreta")
    }

}